<?php

namespace SoftUniBlogBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;
use SoftUniBlogBundle\Entity\Article;
use SoftUniBlogBundle\Form\ArticleType;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

class ArticleController extends Controller
{

    /**
     * @Route("/article/delete/{id}", name="article_delete")
     * @param $id
     */
    public function deleteAction($id)
    {
        $repository=$this->getDoctrine()->getManager()->getRepository(Article::class);
        $article=$repository
            ->find($id);
        $currentUser=$this->getUser();
        if (!$article->isAuthor($currentUser) && !$currentUser->isAdmin()){
            return $this->redirectToRoute("blog_index");
        }
        $em=$this->getDoctrine()->getManager();
        $em->remove($article);
        $em->flush();
        return $this->redirectToRoute("blog_index");
    }
    /**
     * @Route("/article/edit/{id}", name="article_edit")
     */
    public function editAction($id, Request $request)
    {
        $article = $this->getDoctrine()->getRepository(Article::class)->find($id);
        $currentUser=$this->getUser();
        if (!$article->isAuthor($currentUser) && !$currentUser->isAdmin()){
            return $this->redirectToRoute("blog_index");
        }
        $form = $this->createForm(ArticleType::class, $article);

        $form->handleRequest($request);
        if ($form->isValid()){
            $em=$this->getDoctrine()->getManager();
            $em->persist($article);
            $em->flush();

            return $this->redirectToRoute("article_view",['id'=>$id]);
        }

       return $this->render("article/edit.html.twig",
           ['form'=>$form->createView(),
           'article'=>$article]);
    }
    /**
     * @param Request $request
     * @Route("/article/create", name="article_create")
     * @Security("is_granted('IS_AUTHENTICATED_FULLY')")
     * @return \Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function create(Request $request)
    {
        $article = new Article();
        $form = $this->createForm(ArticleType::class, $article);

        $form->handleRequest($request);
        if ($form->isSubmitted()&&$form->isValid())
        {
            $article->setAuthor(($this->getUser()));
            $em=$this->getDoctrine()->getManager();
            $em->persist($article);
            $em->flush();
            return $this->redirectToRoute('blog_index');
        }
        return $this->render('article/create.html.twig',
            array('form' => $form->createView()));
    }
    /**
     * @Route("/article/{id}", name="article_view")
     * @param $id
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function viewArticle($id)
    {
        $article=$this->getDoctrine()->getRepository(Article::class)->find($id);
        return $this->render('article/article.html.twig', ['article'=> $article]);
    }
}